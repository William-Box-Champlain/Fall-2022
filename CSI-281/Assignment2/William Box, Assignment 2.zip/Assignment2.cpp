/*
Author: William Box
Class: CSI-281-01
Assignment: PA 2
Date Assigned: Sept 16
Due Date: Sept 20 13:00
Description:

Main file used to test the functions written within sortingFunctions.h

Certification of Authenticity:
I certify that this is entirely my own work, except where I have given
fully-documented references to the work of others. I understand the definition and
consequences of plagiarism and acknowledge that the assessor of this assignment
may, for the purpose of assessing this assignment:
- Reproduce this assignment and provide a copy to another member of academic staff;
and/or
- Communicate a copy of this assignment to a plagiarism checking service (which may
then retain a copy of this assignment on its database for the purpose of future
plagiarism checking)
*/

#include <iostream>
#include "sortingFunctions.h"

/*
* Pre: requires an array, as well as the array's length
* Post: the array should be displayed to the console
* Purpose: display an array's contents to the console
*/
template <typename T>
void coutArray(T list[], int length)
{
    for (size_t i = 0; i < length; i++)
    {
        std::cout << list[i] << " ";
    }
    std::cout << std::endl;
}

int main()
{
    //declare unsorted array's and their length
    const int arrayLength = 5;
    int bubbleArray[arrayLength] = {1,5,2,4,3};
    int insertionArray[arrayLength] = { 1,5,2,4,3 };
    std::string bubbleStringArray[arrayLength] = { "c","n","t","i","e" };
    std::string insertionStringArray[arrayLength] = { "c","n","t","i","e" };
    
    //display unsorted array, sort array with bubble-sort, and display the sorted array
    std::cout << "Unsorted int array: ";
    coutArray(bubbleArray, arrayLength);

    bubbleSort(bubbleArray, arrayLength);

    std::cout << "Sorted with bubbleSort(): ";
    coutArray(bubbleArray, arrayLength);
    std::cout << std::endl;

    //display unsorted array, sort array with insertion-sort, and display the sorted array
    std::cout << "Unsorted int array: ";
    coutArray(insertionArray, arrayLength);

    insertionSort(insertionArray, arrayLength);
    
    std::cout << "Sorted with insertionSort(): ";
    coutArray(insertionArray, arrayLength);
    std::cout << std::endl;

    //display unsorted array, sort array with bubble-sort, and display the sorted array
    std::cout << "Unsorted string array: ";
    coutArray(bubbleStringArray, arrayLength);
    
    bubbleSort(bubbleStringArray, arrayLength);
    
    std::cout << "Sorted with bubbleSort(): ";
    coutArray(bubbleStringArray, arrayLength);
    std::cout << std::endl;

    //display unsorted array, sort array with insertion-sort, and display the sorted array
    std::cout << "Unsorted string array: ";
    coutArray(insertionStringArray, arrayLength);
    
    insertionSort(insertionStringArray, arrayLength);
    
    std::cout << "Sorted with insertionSort(): ";
    coutArray(insertionStringArray, arrayLength);
    std::cout << std::endl;

    return 0;
}