#pragma once
template <class T>
class boxVector //my implementation of a dynamic array similar to the std::vector class
{

};